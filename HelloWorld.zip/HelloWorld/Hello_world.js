

var text = "Hello World";

document.getElementById("heading1").innerHTML = text ;
